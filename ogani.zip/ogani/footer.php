<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ogani
 */

?>
<!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <?php  dynamic_sidebar('footer-1'); ?>
                </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                <div class="footer__widget">
                    <?php  dynamic_sidebar('footer-2'); ?>
                </div> 
                </div>
                <div class="col-lg-4 col-md-12">
                <div class="footer__widget">
                    <?php  dynamic_sidebar('footer-3'); ?>
                </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><?php 
                        global $redux_demo;
                        echo  $footer_text = $redux_demo['footer_text'];
                        ?></p></div>
                        <div class="footer__copyright__payment">
                        <?php 
                            $footer_payment_img = $redux_demo['footer_payment_img']['url'];
                           
                        ?>
                            <img src="<?php echo  $footer_payment_img;?>" alt="">
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->

<?php wp_footer(); ?>

</body>

</html>