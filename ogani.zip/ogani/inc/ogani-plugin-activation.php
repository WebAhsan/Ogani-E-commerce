<?php 


require_once get_template_directory(). '/inc/class-tgm-plugin-activation.php';


function ogani_plugin_activatin(){

    $plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Advanced Custom Fields', // The plugin name.
			'slug'               => 'advanced-custom-fields', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'WooCommerce', // The plugin name.
			'slug'               => 'woocommerce', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Contact Form 7', // The plugin name.
			'slug'               => 'contact-form-7', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'One Click Demo Import', // The plugin name.
			'slug'               => 'one-click-demo-import', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Yith Woocommerce Compare', // The plugin name.
			'slug'               => 'yith-woocommerce-compare', // The plugin slug (typically the folder name). 
        ),
		array(
			'name'               => 'YITH WooCommerce Wishlist', // The plugin name.
			'slug'               => 'yith-woocommerce-wishlist', // The plugin slug (typically the folder name). 
        ),
		// <snip />
	);
    $config = array(
        'id'           => 'ogani_plugin_activation',                 // Unique ID for hashing notices for multiple instances of TGMPA.                 // Default absolute path to bundled plugins.
        'menu'         => 'ogani-plugin-activation', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
    );
    tgmpa( $plugins, $config );

   

}

add_action( 'tgmpa_register', 'ogani_plugin_activatin' );



