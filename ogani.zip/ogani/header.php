<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ogani
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); 
      global $woocommerce;
    ?>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
    <!-- Page Preloder --
    <div id="preloder">
        <div class="loader"></div>
    </div>

  Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="img/logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-heart"></i> <span>1</span></a></li>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul>
            <div class="header__cart__price">item: <span>      
            <?php    
            echo $woocommerce->cart->get_cart_total(); ?>
            </span></div>
        </div>
        <div class="humberger__menu__widget">
            <div class="header__top__right__language">
                <img src="img/language.png" alt="">
                <div>English</div>
                <span class="arrow_carrot-down"></span>
                <ul>
                    <li><a href="#">Spanis</a></li>
                    <li><a href="#">English</a></li>
                </ul>
            </div>
            <div class="header__top__right__auth">
                <a href="#"><i class="fa fa-user"></i>  <?php

                $user_name = wp_get_current_user();
                if ( is_user_logged_in() ) {
                    echo $user_name->display_name ;
                } else {
                    echo 'Welcome, visitor!';
                }
                ?></a>
            </div>
        </div>
        <nav class="humberger__menu__nav mobile-menu">



            <ul>
                <li class="active"><a href="./index.html">Home</a></li>
                <li><a href="./shop-grid.html">Shop</a></li>
                <li><a href="#">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="./shop-details.html">Shop Details</a></li>
                        <li><a href="./shoping-cart.html">Shoping Cart</a></li>
                        <li><a href="./checkout.html">Check Out</a></li>
                        <li><a href="./blog-details.html">Blog Details</a></li>
                    </ul>
                </li>
                <li><a href="./blog.html">Blog</a></li>
                <li><a href="./contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        <div class="humberger__menu__contact">
            <ul>
                <li><i class="fa fa-envelope"></i> hello@colorlib.com</li>
                <li>Free Shipping for all Order of $99</li>
            </ul>
        </div>
    </div>
    <!-- Humberger End -->

    <?php 

    global $redux_demo;
    $header_email = $redux_demo['header-email-section'];
    $header_message = $redux_demo['header-hot-message'];
    $social_facebook = $redux_demo['social-facebook'];
    $social_twitter = $redux_demo['social-twitter'];
    $social_linkedin = $redux_demo['social-linkedin'];
    $social_pinterest = $redux_demo['social-pinterest'];

    
    
    ?>
    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__left">
                            <ul>
                                <?php if( $header_email ){?>
                                <li><i class="fa fa-envelope"></i> <?php echo $header_email ; ?></li>
                                <?php }?>
                                <li> <?php echo $header_message ; ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <?php if($social_facebook){ ?>
                                <a href="<?php echo $social_facebook;?>"><i class="fa fa-facebook"></i></a>
                                <?php }?>
                                <?php if($social_twitter){ ?>
                                <a href="<?php echo $social_twitter;?>"><i class="fa fa-twitter"></i></a>
                                <?php }?>
                                <?php if($social_linkedin){ ?>
                                <a href="<?php echo $social_linkedin;?>"><i class="fa fa-linkedin"></i></a>
                                <?php }?>
                                <?php if($social_pinterest){ ?>
                                <a href="<?php echo $social_pinterest;?>"><i class="fa fa-pinterest-p"></i></a>
                                <?php }?>
                               
                            </div>
                            <div class="header__top__right__language">
                                <img src="img/language.png" alt="">
                                <div>English</div>
                                <span class="arrow_carrot-down"></span>
                                <ul>
                                    <li><a href="#">Spanis</a></li>
                                    <li><a href="#">English</a></li>
                                </ul>
                            </div>
                            <div class="header__top__right__auth">
                                <span>
                                <?php

                                $user_name = wp_get_current_user();
                                if ( is_user_logged_in() ) {
                                    echo '<i class="fa fa-user user_btn"></i>'.$user_name->display_name ;?>
                                    <a href="<?php echo wp_logout_url(); ?>"><i class="fa fa-sign-out user_btn"></i> Logout</a>
                                <?php    
                                    
                                } else {
                                    echo ' <a href="/wp-login.php" title="Members Area Login" rel="home"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign In</a>';
                                }
                                ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                       <a href="<?php echo site_url('/'); ?>">
                        <?php 
                                $custom_logo_id = get_theme_mod( 'custom_logo' );
                                $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                
                                if ( has_custom_logo() ) {
                                    echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                                } else {
                                    echo '<h1>' . get_bloginfo('name') . '</h1>';
                                }
                        ?>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                            <?php   
                                wp_nav_menu( array(
                                    'menu'           => 'Project Nav', // Do not fall back to first non-empty menu.
                                    'theme_location' => 'menu-1',
                                    'container_class'=> 'header__menu',
                                    'container'      => 'nav',
                                ) );
		                     ?>
                </div>
                <div class="col-lg-3">
                    <div class="header__cart">
                        <ul>
                            <li><a href=" <?php  echo get_page_link(66); ?>"><i class="fa fa-heart"></i> <span>
                                <?php
                                  $count = 0;
                                    if( function_exists( 'yith_wcwl_count_products' ) ){
                                   echo $count = yith_wcwl_count_products();
                                  }
                              ?>
                            </span></a></li>
                            <li><a href="<?php echo wc_get_cart_url(); ?>"><i class="fa fa-shopping-bag"></i> <span>

                            <?php
                            $sale_total =  $woocommerce->cart->cart_contents_count;
                            echo $sale_total;
                            ?>
                            </span></a></li>
                        </ul>
                        <div class="header__cart__price">item: <span>

                        <?php 

                         $sale_total  =  $woocommerce->cart->get_cart_total();
                         echo $sale_total;
                         ?>
                        </span></div>
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->